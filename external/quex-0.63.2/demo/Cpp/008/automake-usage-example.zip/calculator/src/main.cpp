#include <fstream>    
#include <iostream> 
#include <Calc_parser.h>
#include <Calc_lexer>

int Calc_yyparse(quex::Calc_lexer  *qlex);

int main(int argc, char** argv) 
{
	quex::Calc_lexer qlex(argc == 1 ? "../share/calculator_example.txt" : argv[1]);
	int ret = Calc_yyparse(&qlex);
	if (ret!=0)
	{
		std::cout << "Some error in yyparse\n";
		return ret;
	}
	return 0;
}
