#!/bin/sh
autoreconf --force --install -I conf
exit 0
